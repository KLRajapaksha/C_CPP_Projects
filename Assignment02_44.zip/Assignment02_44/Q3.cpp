#include<iostream>

using namespace std;

int main(){
	int N;//number of products
	int i=0;
	int j=0;
	int val;
	int count=0;
	cin>>N;
	int weight[N];
	for(i=0;i<N;i++){
		cin>>weight[i];
	}
	//sort weights to increasing order
	for(i=0;i<N-1;i++){
		for(j=i;j<N;j++){
			if(weight[i]>weight[j]){
				val=weight[j];
				weight[j]=weight[i];
				weight[i]=val;
			}
		}
	}
	
	i=0;
	//count = number of containers
	if(N!=0){//if there are at least one product to ship, 
		count++;//add first product to the container
		val=weight[0];// weights are in the ascending order, so 1st one is the smallest weight
		for(i=0;i<N;i++){
			if((val+4)<weight[i]){//if next product weights morre than smallest weight+4, container count ++
				count++;
				val=weight[i]; // smallest weight in the new container
			}
		}
	}else{
		count=0; // if there are no products to ship, we don't need any containers
	}
	cout<<count;// display number of containers need
}
