#include <iostream>

using namespace std;

int main()
{
    int num,i;
    cin>>num; //inserting of numbr of students
    int scores[num+2]; //array to store score of students
    int masks[num+2]; //array to store number of masks
    int total=0;
    int max;
    
    scores[0]=100001; //assign higher value than limit for comparision
    scores[num+1]=100001; //assign higher value than limit for comparison

    for ( i = 0; i < num+2; i++ )
    {
        masks[i]=0; //initializing number of masks to 0 for all students
    }

    for ( i = 0; i < num; i++ ) //insertion of scores
    {
        cin>>scores[i+1];
    }

    // for(i=0;i<num+2;i++)cout<<scores[i]<<" ";
    // cout<<endl;
    
    for ( i = 1; i < num+1; i++ ) //assigning minimum number of masks(1) for least scored students from both sides
    {
        if (scores[i]<=scores[i-1] && scores[i]<=scores[i+1])
        {
            masks[i]=1;
            total=total+1;
        }
    }

    // for(i=0;i<num+2;i++)cout<<masks[i]<<" ";
    // cout<<endl;
    
    for ( i = 1; i < num+1; i++ ) //students having scores greater than next one but less than the previous one
    {
        if (scores[i]<=scores[i-1] && scores[i]>scores[i+1])
        {
            masks[i]=masks[i+1]+1;
            total=total+masks[i+1]+1;
        }
    }

    // for(i=0;i<num+2;i++)cout<<masks[i]<<" ";
    // cout<<endl;

    for ( i = 1; i < num+1; i++ ) //students having scores greater than previous one but less than the next one
    {
        if (scores[i]>scores[i-1] && scores[i]<=scores[i+1])
        {
            masks[i]=masks[i-1]+1;
            total=total+masks[i-1]+1;
        }
    }

    // for(i=0;i<num+2;i++)cout<<masks[i]<<" ";
    // cout<<endl;

    for ( i = 1; i < num+1; i++ ) //students having scores higher than both sides
    {
        if (scores[i]>scores[i-1] && scores[i]>scores[i+1])
        {
            if(masks[i-1]>=masks[i+1]) //finding the max from both sides
            {
                max=masks[i-1]+1;
            }
            else
            {
                max=masks[i+1]+1;
            }
            
            masks[i]=max;
            total=total+max;
        }
    }

    // for(i=0;i<num+2;i++)cout<<masks[i]<<" ";
    // cout<<endl;

    cout<<total; //final output

}