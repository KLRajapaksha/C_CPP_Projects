#include<iostream>

using namespace std;

int main(){
	int N,M;//N-number of bottels M-number of barrels
	int i=0;
	int j=0;
	int temp=0;
	int value=0;
	int val_1,val_2;
	cin>>N>>M;
	//input barrel volumes
	

	int barrelVolume[M];
	for(i=0;i<M;i++){
		cin>>barrelVolume[i];
	}
	//input barrel prices
	int barrelPrice[M];
	for(i=0;i<M;i++){
		cin>>barrelPrice[i];
	}
	//get value for price per bottel
	for(i=0;i<M;i++){
		barrelPrice[i]=barrelPrice[i]/barrelVolume[i];
	}
	
	//sort arrys to decresing ordeer of the price per bottel 
	for(i=0;i<M-1;i++){
		for(j=i;j<M;j++){
			if(barrelPrice[i]<barrelPrice[j]){
				val_1=barrelPrice[j];
				val_2=barrelVolume[j];    // sort barrelVolume array according to the barrelPrice array
				barrelPrice[j]=barrelPrice[i];
				barrelVolume[j]=barrelVolume[i];
				barrelPrice[i]=val_1;
				barrelVolume[i]=val_2;	
			}
		}
	}
	
	//to find the maximum value
	for(i=0;i<M;i++){
		while((!barrelVolume[i]==0) && (temp<N)){ 
			value=value+barrelPrice[i];
			barrelVolume[i]--;			
			temp++;
			if(temp==N){
				cout<<value;
				break;
			}
					
		}
		
	}	
	

}
